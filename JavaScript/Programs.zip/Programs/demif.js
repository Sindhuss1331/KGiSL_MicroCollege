var n1 = parseInt(prompt("Enter any Number"));

            if(n1>0)
            {
              document.write("The Number is positive"+n1);
            }
            else
            {
                alert("Enter only positive number");
            }