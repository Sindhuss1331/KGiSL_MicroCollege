function msg()
{
    alert("You have clicked button .. welcome");
}