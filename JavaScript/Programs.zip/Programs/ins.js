function display()
{
    var n1 = prompt("Enter your name:");
    document.getElementById("msg").innerHTML=n1;
    document.getElementById("msg").style.color="blue";
    document.getElementById("msg").style.fontSize="25px";
    document.getElementById("msg").style.fontStyle="bold";

    document.getElementById("bg").style.backgroundColor="yellow";

}


