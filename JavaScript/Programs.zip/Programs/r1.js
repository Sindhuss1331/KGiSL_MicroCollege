/*var s1 = "FullStack",year="2023",salary=55000.36;

console.log(typeof(s1));
console.log(typeof(year));
console.log(typeof(salary));

console.log("Name of course:"+s1+"year:"+year+"salary:"+salary)*/

var a=5,b=5;
var s1 = "5";

console.log((a==b));
console.log((a===s1));