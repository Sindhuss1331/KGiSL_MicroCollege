var n1 = parseInt(prompt("Enter any Number"));

switch(n1)
{
    case 90:
        document.write("Distinction");
        break;
    case 80:
        document.write("first class");
        break;
    case 50:
        document.write("second class");
        break;
    default:
        document.write("Fail");
        break;
}