var n1 = parseInt(prompt("Enter any Number"));

if((n1>=1) && (n1<11))
{
    alert("The number between 1 to 10");
}
else if((n1>=11) && (n1<21))
{
    alert("The number between 11 to 20");
}
else 
{
    alert("The number is out of range");
}